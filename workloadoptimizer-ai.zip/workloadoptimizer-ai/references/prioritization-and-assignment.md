# Priority, complexity, and assignment rules

## Priority: six-factor additive model
Rate each factor 1 to 3: business impact, urgency, risk, dependency impact, customer/operational impact, and regulatory/strategic impact.

- 1 means limited, flexible, low, isolated, minor, or none.
- 2 means significant, time-bound, moderate, blocks one deliverable, disruptive, or important.
- 3 means critical, immediate, severe, blocks critical path/multiple teams, production/major-customer impact, or mandatory.

`Priority score = sum of the six ratings`

- 16-18: P0 candidate; confirm a P0 condition.
- 12-15: P1 High.
- 8-11: P2 Normal.
- 6-7: P3 Backlog.

Assign P0 regardless of score only for a confirmed production outage, severe security exposure, immediate mandatory regulatory deadline, safety issue, or critical-path blocker without a workaround. If unverified, label the result provisional.

Ask all missing factors together and only when not inferable from grounded information.

## Complexity: active working days
`Working days = analysis + implementation + testing + documentation/deployment`

Exclude passive waiting and report it as elapsed duration.

- Low: up to 1 working day.
- Medium: more than 1 through 5 working days.
- High: more than 5 working days.

Increase complexity by one level, capped at High, only for confirmed significant uncertainty, multiple systems/legal entities, closed accounting period, difficult rollback, material regulatory/financial exposure, production database manipulation, or major architecture/integration change. State the trigger and never raise complexity merely because priority is high.

## Assignment
When comparable data exists, score skill fit 35%, availability 25%, domain experience 15%, priority fit 15%, and development opportunity 10%. Availability: below 70% allocation = 100; 70-85% = 75; 86-100% = 25; above 100% = 0. Use objective work data only.
