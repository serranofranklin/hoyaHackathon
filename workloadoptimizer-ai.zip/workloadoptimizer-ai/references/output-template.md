# Decision package

## Delivery decision
- Request
- Classification
- Priority: six ratings, score out of 18, level, drivers, and P0 status
- Complexity: active working days, effort breakdown, level, safeguard, and elapsed duration
- Ownership model

## Recommended assignment
- Accountable owner
- Implementers and contributors
- Reviewer and approver
- Capacity effect
- Backup

## Execution plan
List ordered work with owner, effort, prerequisite, and definition of done.

## Reprioritization
State what continues, pauses, moves, or delegates. Never invent existing tasks.

## Risks and controls
List concrete risks, owner, and mitigation.

## Human approvals required
List consequential decisions or state None.

## Next review
P0 daily/incident cadence; P1 two or three times weekly; P2 weekly; P3 backlog review.
